//
//  Make_WavesApp.swift
//  Make Waves
//
//  Created by Stephen DeStefano on 1/21/22.
//

import SwiftUI

@main
struct Make_WavesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
